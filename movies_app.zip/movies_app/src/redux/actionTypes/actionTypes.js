export const ActionTypes = {
  FETCH_MOVIES: 'FETCH_MOVIES',
};
